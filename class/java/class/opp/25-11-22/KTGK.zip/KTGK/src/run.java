public class run {
    public static void main(String[] args) throws Exception {
        QLSach s1 = new QLSach();
        s1.nhap();
        s1.xuat();
        s1.doanhThu();
        s1.doanh_thu_max();
    }
}
